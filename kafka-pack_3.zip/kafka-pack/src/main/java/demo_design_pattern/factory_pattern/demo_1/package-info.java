@ShapeImplemented(implementationsOfShape = {Circle.class, Rectangle.class, Square.class})
package demo_design_pattern.factory_pattern.demo_1;

