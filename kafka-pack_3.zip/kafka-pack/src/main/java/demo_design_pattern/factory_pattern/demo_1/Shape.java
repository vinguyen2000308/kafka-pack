package demo_design_pattern.factory_pattern.demo_1;

public interface Shape {
    void draw();

}
