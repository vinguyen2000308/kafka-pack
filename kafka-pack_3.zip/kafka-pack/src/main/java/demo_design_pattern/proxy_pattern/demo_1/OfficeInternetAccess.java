package demo_design_pattern.proxy_pattern.demo_1;

public interface OfficeInternetAccess {
    public void grantInternetAccess();
}
