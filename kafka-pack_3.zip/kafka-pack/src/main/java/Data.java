import java.io.Serializable;

public class Data implements Serializable {
    public Data() {
    }
}
