import lombok.Builder;

public class Person extends Data {
    private String name;
    private Integer date;
    private Address address;

    public Person() {
    }

    public Person(String name, Integer date) {
        this.name = name;
        this.date = date;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getDate() {
        return date;
    }

    public void setDate(Integer date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", date=" + date +
                ", address=" + address +
                '}';
    }
}
