import org.apache.kafka.clients.producer.ProducerConfig;
import scala.collection.immutable.Stream;

import java.util.Properties;

public class AdminConfig {

    public static Properties getPropertiesForAdmin() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, Const.BOOTSTRAP_SERVER);
        return props;
    }

}
