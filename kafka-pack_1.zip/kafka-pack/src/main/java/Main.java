import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.admin.Admin;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.DeleteTopicsResult;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.KafkaFuture;
import org.apache.kafka.common.PartitionInfo;

import java.io.IOException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

public class Main {

    // ./kafka-topics.sh --list --zookeeper 10.60.105.38:8352
    // ./kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic sale-service  --from-beginning | grep 19e416b723a90956
    // ./kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic order-service  --from-beginning
    // ./kafka-console-consumer.sh --bootstrap-server 10.60.105.38:8353 --topic com.viettel.bccs3.saga.tramsaga.post_2_pre.ExecuteChangePostpaidToPrepaidSaga-reply  --from-beginning


    //list all topic  server bin/kafka-topics.sh --list --zookeeper 10.60.105.38:8352
    // see the message

    // bin/kafka-console-consumer.sh --topic topic-name --from-beginning --bootstrap-server 10.60.105.38:8353


    public static void main(String[] args) throws IOException {

//        writeMessage("test2");
        sendMessageV1(generateData(), "test5");
        try {
            readMessageV1("test5", Person.class.getName());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
//        try {
//            Class<?> c = Class.forName("Person");
//            System.out.println(c);
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//        }


    }

    public static Admin createAdmin() {
        Properties props = new Properties();
        // add config for admin properties
        props.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, Const.BOOTSTRAP_SERVER);
        Admin admin = null;
        try {
            admin = Admin.create(props);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return admin;
    }

    public static void deleteTopic(String topicName, Admin admin) {
        try {
            // Create a compacted topic
            DeleteTopicsResult deleteTopicsResult = admin.deleteTopics(Arrays.asList(topicName));

            // Call values() to get the result for a specific topic
            KafkaFuture<Void> future = deleteTopicsResult.values().get(topicName);

            // Call get() to block until the topic creation is complete or has failed
            // if creation failed the ExecutionException wraps the underlying cause.
            future.get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    public static void listAllTopic() {
        // List topic from zookeeper
        Map<String, List<PartitionInfo>> topics;

        Properties props = new Properties();
        props.put("bootstrap.servers", Const.BOOTSTRAP_SERVER);
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");


        KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(props);
        topics = consumer.listTopics();
        topics.keySet().forEach(System.out::println);
        consumer.close();
    }


    public static Properties getPropertiesForProducer() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, Const.BOOTSTRAP_SERVER);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, Const.KAFKA_STRING_SERIALIZER);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, Const.KAFKA_STRING_SERIALIZER);
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        return props;
    }

    public static Properties getPropertiesForConsumer() {
        Properties consumerProps = new Properties();
        consumerProps.put("bootstrap.servers", Const.BOOTSTRAP_SERVER);
        consumerProps.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        consumerProps.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        consumerProps.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        consumerProps.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, true);
        consumerProps.put(ConsumerConfig.GROUP_ID_CONFIG, "group1");
        return consumerProps;
    }


    public static void getPartitionInfo(List<String> topics) {
        Properties props = getPropertiesForProducer();
        Producer<String, String> producer = new KafkaProducer<>(props);
        topics.forEach(item -> {
            List<PartitionInfo> partitionInfos = producer.partitionsFor(item);
            partitionInfos.forEach(System.out::println);
        });
    }

    public static void createTopic(String topicName, int numPartitions, int replicationFactor) {
        NewTopic newTopic = new NewTopic(topicName, numPartitions, (short) replicationFactor);

    }

    public static Data generateData() {
        SecureRandom secureRandom = new SecureRandom();
        Person person = new Person("nguyenvi", secureRandom.nextInt(100));
        Address address = new Address();
        address.setAddress1("Ha Noi");
        address.setAddress2("Ho Chi Minh");
        address.setZipCode(10000l);
        person.setAddress(address);
        return person;
    }


    public static void sendMessageV1(Data data, String topicName) {
        Properties props = getPropertiesForProducer();
        Producer<String, String> producer = new KafkaProducer<>(props);
        ObjectMapper mapper = new ObjectMapper();
        try {
            String key = String.valueOf(Math.random());
            RecordMetadata recordMetadata = producer.send(new ProducerRecord<>(topicName, key, mapper.writeValueAsString(data))).get();
            System.out.println("Record sent with key " + key + " to partition " + recordMetadata.partition() + " with offset " + recordMetadata.offset());

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            producer.close();
        }
    }

    public static void sendMessage(String topicName) {

        // For convert Json String to Object

        Properties props = getPropertiesForProducer();
        Producer<String, String> producer = new KafkaProducer<>(props);
        Person person = new Person("nguyenvi", 21);
        Address address = new Address();
        address.setAddress1("Ha Noi");
        address.setAddress2("Ho Chi Minh");
        address.setZipCode(10000l);
        person.setAddress(address);
        ObjectMapper mapper = new ObjectMapper();
        try {
            // Converting the Java object into a JSON string
            String jsonStr = mapper.writeValueAsString(person);
            // Displaying Java object into a JSON string
            String key = String.valueOf(Math.random());
            RecordMetadata recordMetadata = producer.send(new ProducerRecord<>(topicName, key, jsonStr)).get();
            System.out.println("Record sent with key " + key + " to partition " + recordMetadata.partition()
                    + " with offset " + recordMetadata.offset());

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            producer.close();
        }

    }

    public static void readMessageV1(String topicName, String classNameInput) throws IOException, ClassNotFoundException {
        // Base on metadata to process
        // How to parse Data
        // Get a string -> get class of all project -> parse based on exception
        // data and name class
        Consumer<String, String> consumer = new KafkaConsumer<>(getPropertiesForConsumer());
        consumer.subscribe(Arrays.asList(topicName));
        while (true) {
            ConsumerRecords<String, String> records = consumer.poll(100);
            for (ConsumerRecord<String, String> record : records) {
                Class<?> className = Class.forName(classNameInput);
                System.out.printf("offset = %d, key = %s, value = %s%n", record.offset(), record.key(), record.value());
                System.out.println(new ObjectMapper().readValue(record.value(), className));

            }
        }
    }

    public static void readMessage(String topicName) throws IOException {
        Properties consumerProps = getPropertiesForConsumer();
        Consumer<String, String> consumer = new KafkaConsumer<>(consumerProps);
        consumer.subscribe(Arrays.asList(topicName));
        while (true) {
            ConsumerRecords<String, String> records = consumer.poll(100);
            for (ConsumerRecord<String, String> record : records) {
                Object convertedPerson = new ObjectMapper().readValue(record.value(), Object.class);
                System.out.println("===================== ");
                System.out.printf("offset = %d, key = %s, value = %s%n", record.offset(), record.key(), record.value());
                System.out.println(convertedPerson);

            }
        }
    }

}
