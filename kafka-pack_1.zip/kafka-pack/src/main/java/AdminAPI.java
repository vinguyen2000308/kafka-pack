import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.CreateTopicsResult;
import org.apache.kafka.clients.admin.DeleteTopicsResult;
import org.apache.kafka.clients.admin.NewTopic;

import java.util.Arrays;
import java.util.Collections;

public class AdminAPI {
    public static void createTopic(String topicName, int numPartitions, int replicationFactor) {
        NewTopic newTopic = new NewTopic(topicName, numPartitions, (short) replicationFactor);
        AdminClient adminClient = AdminClient.create(AdminConfig.getPropertiesForAdmin());
        CreateTopicsResult createTopicsResult = adminClient.createTopics(Arrays.asList(newTopic));
        System.out.println(createTopicsResult.values());
    }
    public static void deleteTopic(String topicName)
    {
        AdminClient adminClient = AdminClient.create(AdminConfig.getPropertiesForAdmin());
        DeleteTopicsResult deleteTopicsResult = adminClient.deleteTopics(Collections.singleton(topicName));
        System.out.println(deleteTopicsResult.topicNameValues());
    }
}
