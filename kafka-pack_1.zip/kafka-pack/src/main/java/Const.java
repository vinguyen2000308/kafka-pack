public class Const {

    public static final String BOOTSTRAP_SERVER = "localhost:9092";
    public static final String KAFKA_STRING_SERIALIZER = "org.apache.kafka.common.serialization.StringSerializer";
}
